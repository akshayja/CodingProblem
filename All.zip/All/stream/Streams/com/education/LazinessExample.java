package com.education;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
//. Java 8 Streams do not process the collection operations until user actually starts using it.

public class LazinessExample {
	public static void main(String[] args) throws InterruptedException {
		EmployeeDataSet employeeDataSet=new EmployeeDataSet();
		List<Employee> employees=employeeDataSet.getEmployeeList();
		
		Stream<String> streamOfNames = employees.stream()
				.map(employee -> {
					System.out.println("In Map - " + employee.getEmpName());
					return employee.getEmpName();
				});
		//Just to add some delay
		for (int i = 1; i <= 5; i++) {
			Thread.sleep(1000);
			System.out.println(i + " sec");
		}
		//Called a terminal operation on the stream
		streamOfNames.collect(Collectors.toList());
	}

}
