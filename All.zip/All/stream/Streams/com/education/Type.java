package com.education;

public enum Type {
	EMPLOYEE,
	LEAD,
	MANAGER
}
