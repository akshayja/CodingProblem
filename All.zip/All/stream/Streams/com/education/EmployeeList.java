package com.education;

import java.util.List;
import java.util.stream.Collectors;

public class EmployeeList 
{
	public static void main(String[] args) {
		EmployeeList employeeList=new EmployeeList();
		EmployeeDataSet employeeDataSet=new EmployeeDataSet();
		List<Employee> employees=employeeDataSet.getEmployeeList();
		long start,end;
		start=System.currentTimeMillis();
		System.out.println("***********SEQUENTIAL STREAM OPERATION*********************");
		 System.out.println("Find the average of all the employee salaries-");
		 System.out.println(
	             employees
	                .stream()
	                .mapToInt(employee->employee.getSalary())
	                .average()
	                
	                );
		 end=System.currentTimeMillis(); 
		 employeeList.getTimeRequired(start, end);
		/* start=System.currentTimeMillis();
		 System.out.println("***********PARALLEL STREAM OPERATION*********************");
		 System.out.println("Find the average of all the employee salaries-");
		 System.out.println(
	             employees
	                .parallelStream()
	                .mapToInt(Employee::getSalary)
	                .average()
	                
	                );
		 end=System.currentTimeMillis();
		 employeeList.getTimeRequired(start, end);*/
		 
		 
		 System.out.println("-Filter employees with salaries > 10000-");
		 
		 employees
		 	.stream()
		 		.filter(employee -> employee.getSalary() > 10000)
		 		.forEach(System.out::println);
		 		
		 
		 System.out.println("-What is the lowest salary-");
		 
		 System.out.println("-Find employee with the lowest salary-");
		 
		 System.out.println("-Count of employees with rating > 10000-");
		 		 
		 System.out.println("-Get the summary statistics based on salary-");
		 
		 System.out.println("-List of Managers, comma separated-");
		 
		 System.out.println("-List of Leads , print using foreach-");
		 
		 System.out.println("-List of Employees , sorted, print using foreach-");
		 
		 System.out.println(
	                "-List of Managers, sorted, mapped to upper case, print using foreach-");
		 
		 System.out.println("-Top 3 Leads-");
		 
		 System.out.println("-Find the top salaried Employee-");
		 
		 System.out.println("-Does the Employee list have salary >=1100000?-");
		 
		 System.out.println("-Find the top 5 Employee names having salary greater than 10000 -");
		 
		
		List<String>highSalaryEmployeeNames=
				employees.stream()
				.filter(e->{
								System.out.println("Filtering  ::"+e.getEmpName());
								return e.getSalary()>1000000;
							})
//				.sorted(Comparator.comparing(employee->employee.getSalary()))
	
				.map(employee->{
							System.out.println("Mapping :: "+ employee.getEmpName());
							return employee.getEmpName();		
				})
				.limit(5)
				.collect(Collectors.toList());
			System.out.println(highSalaryEmployeeNames);
	}
	public long getTimeRequired(long start ,long end)
	{
		long diff=end-start;
		System.out.println("Difference is :: "+ diff);
		return diff;
	}
}
