package com.education;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EmployeeDataSet {

	public List<Employee> getEmployeeList()
	{
		List<Employee> employees=new ArrayList<Employee>();
		//create random numbers
		//create random string

		Employee employee=new Employee();
		
		employee.setEmpName("akshay");
		employee.setEmpNo(1);
		employee.setSalary(10000);
		employee.setType(Type.EMPLOYEE);

		Employee employee2=new Employee();
		employee2.setEmpName("omkar");
		employee2.setEmpNo(2);
		employee2.setSalary(20000);
		employee2.setType(Type.LEAD);

		Employee employee3=new Employee();
		employee3.setEmpName("prakash");
		employee3.setEmpNo(3);
		employee3.setSalary(40000);
		employee3.setType(Type.EMPLOYEE);

		Employee employee4=new Employee();
		employee4.setEmpName("raj");
		employee4.setEmpNo(4);
		employee4.setSalary(50000);
		employee4.setType(Type.MANAGER);

		Employee employee5=new Employee();
		employee5.setEmpName("om");
		employee5.setEmpNo(5);
		employee5.setSalary(100020);
		employee5.setType(Type.LEAD);

		Employee employee6=new Employee();
		employee6.setEmpName("raju");
		employee6.setEmpNo(6);
		employee6.setSalary(1000023);
		employee6.setType(Type.MANAGER);

		Employee employee7=new Employee();
		employee7.setEmpName("ram");
		employee7.setEmpNo(7);
		employee7.setSalary(1003200);
		employee7.setType(Type.EMPLOYEE);

		Employee employee8=new Employee();
		employee8.setEmpName("pankaj");
		employee8.setEmpNo(8);
		employee8.setSalary(1230000);
		employee8.setType(Type.LEAD);

		Employee employee9=new Employee();
		employee9.setEmpName("tushar");
		employee9.setEmpNo(9);
		employee9.setSalary(310000);
		employee9.setType(Type.MANAGER);


		employees.add(employee);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
		employees.add(employee6);
		employees.add(employee7);
		employees.add(employee8);
		employees.add(employee9);
		return employees;
	}

	public void getHighSalaryEmployee(List<Employee> employees)
	{
		List<Employee> highSalaryEmployees=new ArrayList<Employee>();
		for(Employee employee:employees)
		{
			if(employee.getSalary()>10000)
			{
				highSalaryEmployees.add(employee);
			}
		}
		
		Collections.sort(highSalaryEmployees,new Comparator<Employee>() {

			@Override
			public int compare(Employee e1, Employee e2) {
				return Integer.compare(e1.getSalary(), e2.getSalary());
			}
		});
		
		//get Names of employees which has high Salary
		List<String> highSalaryEmployeeNames=new ArrayList<String>();
		for(Employee employee:highSalaryEmployees)
		{
			highSalaryEmployeeNames.add(employee.getEmpName());
			
		}
		
	}
}
