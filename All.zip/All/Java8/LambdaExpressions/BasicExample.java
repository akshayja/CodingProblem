
public class BasicExample {
	public static void main(String[] args) {
		n -> n % 2 != 0;
		(char c) -> c == 'y';
		(x, y) -> x + y;
		(int a, int b) -> a * a + b * b;
		() -> 42;
		() -> { return 3.14 };
		(String s) -> { System.out.println(s); };
		() -> { System.out.println("Hello World!"); };
	}
	

}
