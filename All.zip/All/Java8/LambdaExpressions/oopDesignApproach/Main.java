package oopDesignApproach;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MathCommand command=new AddCommand();
		Integer result=command.execute(5, 6);
		System.out.println("result= "+result);
		command=new SubtractCommand();
		 result=command.execute(5, 6);
		System.out.println("result= "+result);
	}

}
