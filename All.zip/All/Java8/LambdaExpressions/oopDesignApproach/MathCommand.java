package oopDesignApproach;

public interface MathCommand
{
	 int execute(int operand1,int operand2);
}