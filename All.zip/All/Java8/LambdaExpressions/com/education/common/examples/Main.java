package com.education.common.examples;

/**
 * 
 */
public class Main {

  public static void main(String[] args) {
    
    RunnableTest.main(args);
    ComparatorTest.main(args);
    ListenerTest.main(args);
  }
}
