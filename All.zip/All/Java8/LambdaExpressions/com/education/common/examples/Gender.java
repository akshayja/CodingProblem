package com.education.common.examples;

/**
 * 
 */
public enum Gender { MALE, FEMALE }
