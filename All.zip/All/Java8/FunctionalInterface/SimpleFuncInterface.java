@FunctionalInterface
public interface SimpleFuncInterface {
 
	public void doWork();
	public String toString();
	public boolean equals(Object o);
}