package com.education;

//In Java, a functional interface is basically an interface with a single abstract method. 
//This kind of interfaces are also known as SAM (Single Abstract Method) types.

import java.awt.event.ActionEvent;
import java.util.EventListener;

public interface ActionListener extends EventListener {

	public void actionPerformed(ActionEvent e);

}
 interface Comparator<T> {
    int compare(T o1, T o2);
}

 interface Callable<V> {
    V call() throws Exception;
}

 interface Runnable {
    public void run();
}
