package com.education;

/* AnonymousInterfaceDemo.java */
//Java Anonymous Implementer of an Interface Type
interface Manageable
{
  public void manage();
}
 
public class AnonymousInterfaceDemo
{
  public static void main(String[] args)
  {
    Manageable m = new Manageable() {
      public void manage()
      {
        System.out.println("It is manageable");
      }			
    }; // anonymous interface implementer closes here
    //m contains an object of anonymous interface implementer of Manageable.
    m.manage();
  }
}