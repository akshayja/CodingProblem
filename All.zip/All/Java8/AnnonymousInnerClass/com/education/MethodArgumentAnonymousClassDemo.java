package com.education;
//Java Anonymous Inner Class in Method Arguments
/* MethodArgumentAnonymousClassDemo.java */

interface Manageable1
{
  public void manage();
}
 
class Manager
{
  public void canManage(Manageable1 m)
  {
	m.manage();
  }
}
public class MethodArgumentAnonymousClassDemo
{
  public static void main(String[] args)
  {
    Manager m = new Manager();
    m.canManage (new Manageable1 ()	
	{
      public void manage()
      {
        System.out.println("Yes, it is being anonymously managed!");
      }			
    }); // anonymous interface implementer as method argument closes here
  }
}