//Anonymous Inner Class as Argument

//Generally if a method accepts an object of an interface, an abstract class, or a concrete class,
//then we can implement the interface, extend the abstract class, and pass the object to the method.
//If it is a class, then we can directly pass it to the method.

//But in all the three cases, you can pass an anonymous inner class to the method.

//interface
interface Message{
   String greet();	
}

public class My_class {
   //method which accepts the object of interface Message
   public void displayMessage(Message m){
      System.out.println(m.greet() +", This is an example of anonymous inner calss as an argument");	   
   }

   public static void main(String args[]){
      //Instantiating the class
      My_class obj=new My_class();
      //Passing an anonymous inner class as an argument
      obj.displayMessage(new Message(){
         public String greet(){
         return "Hello";  		   
      }
      });
   }
}